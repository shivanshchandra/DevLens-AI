# apps/backend/app/worker/jobs.py

import os
import uuid
from pathlib import Path

from app.db.session import SessionLocal
from app.services.scan_service import (
    get_scan,
    set_scan_failed,
    set_scan_result,
    set_scan_status,
)
from app.services.analysis.directory_analyzer import analyze_directory


def run_scan_job(scan_id: str) -> None:
    """
    Background job:
    queued -> running -> completed/failed
    Stores result_json into Postgres.
    """
    db = SessionLocal()
    try:
        sid = uuid.UUID(scan_id)
        scan = get_scan(db, sid)
        if not scan:
            return

        # 1) mark running
        set_scan_status(db, scan, "running")

        # 2) Decide what directory to analyze (TEMP for now)
        # For step-2 validation we analyze backend folder by default.
        # Later we will replace this with:
        # - extracted zip dir
        # - cloned repo dir
        target_dir = Path(os.getenv("DEVLENS_ANALYZE_DIR", Path.cwd())).resolve()

        # 3) run real analysis
        result = analyze_directory(target_dir)

        # 4) store results + mark completed
        set_scan_result(db, scan, result)

    except Exception as e:
        # best effort to mark failed
        try:
            sid = uuid.UUID(scan_id)
            scan = get_scan(db, sid)
            if scan:
                set_scan_failed(db, scan, str(e))
        finally:
            pass
    finally:
        db.close()